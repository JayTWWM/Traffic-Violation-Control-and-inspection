package com.twwm.trafficviolationreport;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class InfoActivity extends AppCompatActivity implements LocationListener{

    private Button photo;
    private Button submit;
    private EditText number;

    protected LocationManager locationManager;

    private String lattitude;
    private String longitude;

    private Map<String,Object> data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        photo = findViewById(R.id.photo);
        submit = findViewById(R.id.submit);
        number = findViewById(R.id.number);

        data = new HashMap<>();

        photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                data.put("Latitude", lattitude);
                data.put("Longitude", longitude);
                data.put("Vehicle Number", number.getText().toString());
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                db.collection("Events").document(number.getText().toString()).set(data).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(InfoActivity.this, "Complaint Taken", Toast.LENGTH_LONG).show();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        startActivity(new Intent(InfoActivity.this, Main2Activity.class));
                    }
                });


            }
        });

    }

    @Override
    public void onLocationChanged(Location location) {

        lattitude = Double.toString(location.getLatitude());
        longitude = Double.toString(location.getLongitude());

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
